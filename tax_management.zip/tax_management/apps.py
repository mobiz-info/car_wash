from django.apps import AppConfig

class TaxManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tax_management'
    verbose_name = 'Tax Management'
